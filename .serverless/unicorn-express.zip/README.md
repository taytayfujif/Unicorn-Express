# Unicorn-Express
Team Name: Home <br />
Team Members: Taylor, Logan, Alex

## Project Challenge
To stir interest/educate high school students to think beyond college and career, and think of purchasing a home.


## Project Proposal
- Create an intteractive informational website (modules) To help stir interest/educate high school students to think beyond college and career, and think of purchasing a home. 
- Vuejs


## Project Plan
List the milestones in your project and high level tasks for each, for example:
- Come up with project idea 
    - brainstorm what information we need
    - contact client for information and goals
- Create wireframe and mockup
    - create simple wireframe
    - create mockup 
- Pitch idea to client 
    - get feedback 
- Start developing components 
    - MVP: informational + modules 
- test website
- Create video demo
- Create presentation
- Stretch Goals 
    - Stretch Goal 1: incorparate firebase 
    - Stretch Goal 2: animations 

      
